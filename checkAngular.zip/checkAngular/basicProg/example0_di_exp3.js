var myparent = function(firstName,lastName)
{
  this.firstName = firstName;
  this.lastName = lastName;
}

var myfun = function(obj1)
{
  console.log("DI: "+JSON.stringify(obj1, null, 1));
}

var ob = new myparent('john','earth');
myfun(ob);

console.log(myfun.toString());
console.log(myfun);
