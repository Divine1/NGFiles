myparent = function(firstName,lastName)
{
  this.firstName = firstName;
  this.lastName = lastName;

}
/*
//example 1
function myfun()
{
  var obj1 = new myparent('john','earth');
  console.log(obj1);
}

myfun();
*/
/*
//example 2
var myfun = function(obj1)
{
//  console.log(obj1);
}

var ob = new myparent('john','earth');
myfun(ob);
//console.log(myfun.toString());
//console.log(myfun);
*/

/*
//example 3
var nameApp = angular.module('nameApp',[]);
  nameApp.controller('myController' , function($scope)
  {
    $scope.myfun = function(var1,var2){

    }
    $scope.myfunDis = function(){
      console.log(angular.injector().annotate($scope.myfun));
    }
  });
*/
