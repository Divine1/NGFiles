var myparent = function(firstName,lastName)
{
  this.firstName = firstName;
  this.lastName = lastName;

}

//example 1
function myfun()
{
  var obj1 = new myparent('john','earth');
  console.log(obj1);
}
myfun();
