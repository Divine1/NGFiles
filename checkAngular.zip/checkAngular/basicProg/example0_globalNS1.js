
person = 'john';

console.log("NS1: i am "+person);
