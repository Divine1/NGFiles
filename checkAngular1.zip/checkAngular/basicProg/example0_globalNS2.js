
console.log("NS2: i am "+person);
