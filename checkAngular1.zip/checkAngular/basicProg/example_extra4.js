    pets =
    [
      {
        "name" : "Johnny JR",
        "weight" : "40kg",
        "location" : "jupiter",
        "imageURL" : "http://localhost/checkAngular/images/pets/pet1.jpg",
        "Skills" : "Plays Football",
        "isAvailable" : false
      },
      {
          "name" : "Johnny SR",
          "weight" : "30kg",
          "location" : "neptune",
          "imageURL" : "http://localhost/checkAngular/images/pets/pet2.jpg",
          "Skills" : "Friendly/Social",
          "isAvailable" : true
      },
      {
          "name" : "Dolphy",
          "weight" : "50kg",
          "location" : "mercury",
          "imageURL" : "http://localhost/checkAngular/images/pets/pet3.jpg",
          "Skills" : "Listens to Music/ Plays Guitar",
          "isAvailable" : true
      },
      {
          "name" : "Pepsi",
          "weight" : "40kg",
          "location" : "jupiter",
          "imageURL" : "http://localhost/checkAngular/images/pets/pet4.jpg",
          "Skills" : "Tracks babies and eats their cookies",
          "isAvailable" : true
      }
    ];
