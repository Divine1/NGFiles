var nameApp = angular.module('nameApp',[]);
  nameApp.controller('myController' , function($scope)
  {
    $scope.myfun = function(var1,var2){
      console.log("var1: "+var1+" | var2: "+var2);
    }
    $scope.myfunDis = function(){
      $scope.myfun("cheese","butter");
      $scope.myfun("cheese");
      console.log($scope.myfun());
      console.log($scope.myfun);
      console.log($scope.myfun.toString());
      console.log(angular.injector().annotate($scope.myfun));
    }
  });
